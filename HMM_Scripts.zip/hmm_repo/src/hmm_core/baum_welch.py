"""
baum_welch.py
-------------
Maximum-likelihood Baum-Welch (EM) parameter estimation for discrete HMMs.

Supports:
- Single or multiple observation sequences
- Multiple random restarts (best log-likelihood selected)
- Convergence monitoring with configurable tolerance

References
----------
Baum, L.E. et al. (1972). An inequality and associated maximization technique
    in statistical estimation for probabilistic functions of Markov processes.
    Inequalities, 3, 1-8.
Dempster, A.P., Laird, N.M., Rubin, D.B. (1977). Maximum likelihood from
    incomplete data via the EM algorithm. JRSS-B, 39(1), 1-38.
"""

import numpy as np
from .forward_backward import posterior, log_likelihood


class BaumWelchHMM:
    """
    Discrete-emission HMM trained by Baum-Welch Expectation-Maximisation.

    Parameters
    ----------
    n_states  : int   — number of hidden states N
    n_obs     : int   — observation alphabet size M
    n_restarts: int   — number of random initialisations (best kept)
    seed      : int   — random seed for reproducibility
    """

    def __init__(self, n_states, n_obs, n_restarts=5, seed=42):
        self.N          = n_states
        self.M          = n_obs
        self.n_restarts = n_restarts
        self.rng        = np.random.default_rng(seed)
        # Parameters (set after fit)
        self.A  = None
        self.B  = None
        self.pi = None
        self.log_likelihoods_ = []   # per-iteration curve of best restart

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit(self, obs, max_iter=200, tol=1e-6):
        """
        Fit the HMM to one or more observation sequences.

        Parameters
        ----------
        obs      : array-like (T,) or list of array-like
                   Single sequence or list of sequences.
        max_iter : int   — maximum EM iterations
        tol      : float — convergence threshold on log-likelihood improvement

        Returns
        -------
        self
        """
        # Support both a single sequence (list/array of ints) and a list of sequences
        if isinstance(obs, list) and len(obs) > 0 and isinstance(obs[0], (list, np.ndarray)):
            obs_list = [np.asarray(o, dtype=int) for o in obs]
        else:
            obs_list = [np.asarray(obs, dtype=int)]

        best_ll   = -np.inf
        best_params = None

        for _ in range(self.n_restarts):
            A, B, pi = self._random_init()
            ll_curve, A, B, pi = self._em(obs_list, A, B, pi, max_iter, tol)
            total_ll = sum(log_likelihood(o, A, B, pi) for o in obs_list)
            if total_ll > best_ll:
                best_ll     = total_ll
                best_params = (A.copy(), B.copy(), pi.copy())
                self.log_likelihoods_ = ll_curve

        self.A, self.B, self.pi = best_params
        return self

    def decode(self, obs):
        """Viterbi decode a single observation sequence."""
        from .viterbi import viterbi_decode
        return viterbi_decode(obs, self.A, self.B, self.pi)

    def score(self, obs):
        """Return log P(O | lambda) for a single sequence."""
        return log_likelihood(np.asarray(obs, dtype=int), self.A, self.B, self.pi)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _random_init(self):
        """Initialise A, B, pi with uniform-Dirichlet random draws."""
        A  = self.rng.dirichlet(np.ones(self.N), size=self.N)
        B  = self.rng.dirichlet(np.ones(self.M), size=self.N)
        pi = self.rng.dirichlet(np.ones(self.N))
        return A, B, pi

    def _em(self, obs_list, A, B, pi, max_iter, tol):
        """Run Baum-Welch EM until convergence or max_iter."""
        prev_ll  = -np.inf
        ll_curve = []

        for iteration in range(max_iter):
            # ---- E-step: accumulate sufficient statistics ----
            A_num  = np.zeros((self.N, self.N))
            B_num  = np.zeros((self.N, self.M))
            pi_num = np.zeros(self.N)
            total_ll = 0.0

            for obs in obs_list:
                obs = np.asarray(obs, dtype=int)
                gamma, xi, ll = posterior(obs, A, B, pi)
                total_ll += ll
                pi_num   += gamma[0]
                A_num    += xi.sum(axis=0)
                for m in range(self.M):
                    B_num[:, m] += gamma[obs == m].sum(axis=0)

            ll_curve.append(total_ll)

            # ---- M-step: normalise ----
            pi = pi_num / pi_num.sum()
            A  = A_num  / A_num.sum(axis=1, keepdims=True)
            B  = B_num  / B_num.sum(axis=1, keepdims=True)

            # ---- Convergence check ----
            if abs(total_ll - prev_ll) < tol:
                break
            prev_ll = total_ll

        return ll_curve, A, B, pi
