"""
viterbi.py
----------
Viterbi algorithm for MAP decoding of the most probable hidden state sequence
in a discrete-emission HMM.

Operates in the log domain throughout to avoid underflow on long sequences.

References
----------
Viterbi, A.J. (1967). Error bounds for convolutional codes and an
    asymptotically optimum decoding algorithm. IEEE Trans. Inf. Theory, 13(2).
Forney, G.D. (1973). The Viterbi algorithm. Proc. IEEE, 61(3), 268-278.
"""

import numpy as np


def viterbi_decode(obs, A, B, pi):
    """
    Find the most probable state sequence for a discrete-emission HMM.

    Parameters
    ----------
    obs : array-like, shape (T,)
        Observation sequence (integer indices into the emission alphabet).
    A   : ndarray, shape (N, N)
        Transition probability matrix.
    B   : ndarray, shape (N, M)
        Emission probability matrix.
    pi  : ndarray, shape (N,)
        Initial state distribution.

    Returns
    -------
    states : ndarray, shape (T,), dtype int
        Most probable (Viterbi) state sequence.
    log_prob : float
        Log-probability of the optimal state sequence.

    Notes
    -----
    Time complexity  : O(N^2 T)
    Space complexity : O(N T)
    """
    obs   = np.asarray(obs, dtype=int)
    T     = len(obs)
    N     = A.shape[0]

    # Work in log domain
    log_A  = np.log(np.maximum(A,  1e-300))
    log_B  = np.log(np.maximum(B,  1e-300))
    log_pi = np.log(np.maximum(pi, 1e-300))

    # delta[t, i] = max log-probability of any path ending in state i at time t
    delta   = np.full((T, N), -np.inf)
    psi     = np.zeros((T, N), dtype=int)   # back-pointer

    # Initialisation
    delta[0] = log_pi + log_B[:, obs[0]]

    # Recursion
    for t in range(1, T):
        trans = delta[t - 1][:, np.newaxis] + log_A       # (N, N)
        psi[t]   = np.argmax(trans, axis=0)               # (N,)
        delta[t] = trans[psi[t], np.arange(N)] + log_B[:, obs[t]]

    # Termination
    log_prob        = np.max(delta[T - 1])
    states          = np.zeros(T, dtype=int)
    states[T - 1]   = np.argmax(delta[T - 1])

    # Back-tracking
    for t in range(T - 2, -1, -1):
        states[t] = psi[t + 1, states[t + 1]]

    return states, log_prob


def viterbi_batch(obs_list, A, B, pi):
    """
    Decode a list of observation sequences.

    Parameters
    ----------
    obs_list : list of array-like
        Multiple observation sequences (may differ in length).
    A, B, pi : HMM parameters (shared across sequences).

    Returns
    -------
    results : list of (states, log_prob) tuples
    """
    return [viterbi_decode(obs, A, B, pi) for obs in obs_list]
