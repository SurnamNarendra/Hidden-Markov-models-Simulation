"""
forward_backward.py
-------------------
Numerically stable Forward-Backward algorithm for discrete-emission HMMs.

All computations use explicit scaling factors (Rabiner 1989, Section V-A) to
prevent floating-point underflow on long sequences.  Log-likelihood is recovered
as  log P(O|lambda) = -sum_t log(c_t).

References
----------
Rabiner, L.R. (1989). A tutorial on hidden Markov models and selected
    applications in speech recognition. Proc. IEEE, 77(2), 257-286.
"""

import numpy as np


# ---------------------------------------------------------------------------
# Forward pass
# ---------------------------------------------------------------------------

def forward(obs, A, B, pi):
    """
    Compute scaled forward variables alpha and scaling coefficients.

    Parameters
    ----------
    obs : array-like, shape (T,)
        Observation sequence (integer indices into the emission alphabet).
    A   : ndarray, shape (N, N)
        Transition probability matrix.  Rows sum to 1.
    B   : ndarray, shape (N, M)
        Emission probability matrix.  Rows sum to 1.
    pi  : ndarray, shape (N,)
        Initial state distribution.

    Returns
    -------
    alpha : ndarray, shape (T, N)
        Scaled forward variables  alpha_hat_t(i).
    c     : ndarray, shape (T,)
        Scaling coefficients.  log P(O|lambda) = -sum(log c).
    """
    obs = np.asarray(obs, dtype=int)
    T = len(obs)
    N = A.shape[0]

    alpha = np.zeros((T, N))
    c     = np.zeros(T)

    # Initialisation
    alpha[0] = pi * B[:, obs[0]]
    c[0]     = alpha[0].sum()
    if c[0] == 0:
        c[0] = 1e-300
    alpha[0] /= c[0]

    # Recursion
    for t in range(1, T):
        alpha[t] = (alpha[t - 1] @ A) * B[:, obs[t]]
        c[t]     = alpha[t].sum()
        if c[t] == 0:
            c[t] = 1e-300
        alpha[t] /= c[t]

    return alpha, c


# ---------------------------------------------------------------------------
# Backward pass
# ---------------------------------------------------------------------------

def backward(obs, A, B, c):
    """
    Compute scaled backward variables beta using pre-computed scaling factors.

    Parameters
    ----------
    obs : array-like, shape (T,)
    A   : ndarray, shape (N, N)
    B   : ndarray, shape (N, M)
    c   : ndarray, shape (T,)  — scaling factors from forward()

    Returns
    -------
    beta : ndarray, shape (T, N)
        Scaled backward variables  beta_hat_t(i).
    """
    obs = np.asarray(obs, dtype=int)
    T = len(obs)
    N = A.shape[0]

    beta = np.zeros((T, N))
    beta[T - 1] = 1.0 / c[T - 1]

    for t in range(T - 2, -1, -1):
        beta[t] = (A * B[:, obs[t + 1]][np.newaxis, :]) @ beta[t + 1]
        beta[t] /= c[t]

    return beta


# ---------------------------------------------------------------------------
# Posterior state and transition probabilities
# ---------------------------------------------------------------------------

def posterior(obs, A, B, pi):
    """
    Compute gamma (state occupancy) and xi (pairwise transition) posteriors.

    Parameters
    ----------
    obs : array-like, shape (T,)
    A   : ndarray, shape (N, N)
    B   : ndarray, shape (N, M)
    pi  : ndarray, shape (N,)

    Returns
    -------
    gamma : ndarray, shape (T, N)
        gamma_t(i) = P(q_t = s_i | O, lambda)
    xi    : ndarray, shape (T-1, N, N)
        xi_t(i,j) = P(q_t = s_i, q_{t+1} = s_j | O, lambda)
    log_likelihood : float
        log P(O | lambda)
    """
    obs = np.asarray(obs, dtype=int)
    T = len(obs)
    N = A.shape[0]

    alpha, c     = forward(obs, A, B, pi)
    beta         = backward(obs, A, B, c)
    log_lik      = -np.sum(np.log(c))

    gamma = alpha * beta
    gamma /= gamma.sum(axis=1, keepdims=True)

    xi = np.zeros((T - 1, N, N))
    for t in range(T - 1):
        num = alpha[t][:, np.newaxis] * A * B[:, obs[t + 1]][np.newaxis, :] * beta[t + 1][np.newaxis, :]
        denom = num.sum()
        xi[t] = num / (denom if denom > 0 else 1e-300)

    return gamma, xi, log_lik


# ---------------------------------------------------------------------------
# Convenience: log-likelihood only
# ---------------------------------------------------------------------------

def log_likelihood(obs, A, B, pi):
    """Return log P(O | lambda) for a single observation sequence."""
    _, c = forward(obs, A, B, pi)
    return -np.sum(np.log(c))
