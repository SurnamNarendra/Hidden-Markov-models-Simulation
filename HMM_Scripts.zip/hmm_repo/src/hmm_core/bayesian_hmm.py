"""
bayesian_hmm.py
---------------
Bayesian-EM (Variational Baum-Welch) for discrete HMMs with Dirichlet priors
on the transition matrix rows and initial state distribution.

The M-step replaces the standard ML normalisation with a Dirichlet posterior
update (MacKay 1997), providing regularisation that prevents degenerate
parameter estimates in low-data regimes.

Update equation (article Eq. 9):
    P(a_i | O, lambda_{-A}) = Dir(alpha_i + sum_t xi_t(i, .))

References
----------
MacKay, D.J.C. (1997). Ensemble learning for hidden Markov models.
    Technical Report, Cavendish Laboratory, Cambridge.
Beal, M.J. (2003). Variational algorithms for approximate Bayesian inference.
    PhD thesis, University College London.
"""

import numpy as np
from .forward_backward import posterior, log_likelihood


class BayesianHMM:
    """
    Bayesian discrete-emission HMM with Dirichlet priors.

    Parameters
    ----------
    n_states  : int   — number of hidden states N
    n_obs     : int   — observation alphabet size M
    alpha0    : float — Dirichlet concentration for rows of A and pi
                        (symmetric prior; alpha0=1.0 corresponds to a
                        uniform Dirichlet; larger values → stronger smoothing)
    beta0     : float — Dirichlet concentration for rows of B
    seed      : int   — random seed
    """

    def __init__(self, n_states, n_obs, alpha0=1.0, beta0=0.1, seed=42):
        self.N      = n_states
        self.M      = n_obs
        self.alpha0 = alpha0        # prior on transitions / initial dist
        self.beta0  = beta0         # prior on emissions
        self.rng    = np.random.default_rng(seed)
        self.A      = None
        self.B      = None
        self.pi     = None
        self.log_likelihoods_ = []

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit(self, obs, max_iter=200, tol=1e-6):
        """
        Fit the Bayesian HMM using Dirichlet-regularised EM.

        Parameters
        ----------
        obs      : array-like (T,) or list of array-like
        max_iter : int
        tol      : float

        Returns
        -------
        self
        """
        # Support both a single sequence (list/array of ints) and a list of sequences
        if isinstance(obs, list) and len(obs) > 0 and isinstance(obs[0], (list, np.ndarray)):
            obs_list = [np.asarray(o, dtype=int) for o in obs]
        else:
            obs_list = [np.asarray(obs, dtype=int)]

        A, B, pi = self._random_init()
        self.log_likelihoods_, self.A, self.B, self.pi = \
            self._bayesian_em(obs_list, A, B, pi, max_iter, tol)
        return self

    def decode(self, obs):
        """Viterbi decode a single observation sequence."""
        from .viterbi import viterbi_decode
        return viterbi_decode(obs, self.A, self.B, self.pi)

    def score(self, obs):
        """Return log P(O | lambda) for a single sequence."""
        return log_likelihood(np.asarray(obs, dtype=int), self.A, self.B, self.pi)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _random_init(self):
        A  = self.rng.dirichlet(np.ones(self.N) * self.alpha0, size=self.N)
        B  = self.rng.dirichlet(np.ones(self.M) * self.beta0,  size=self.N)
        pi = self.rng.dirichlet(np.ones(self.N) * self.alpha0)
        return A, B, pi

    def _bayesian_em(self, obs_list, A, B, pi, max_iter, tol):
        """
        Dirichlet-regularised Baum-Welch EM.

        The only difference from standard ML-EM is the M-step normalisation:
        instead of dividing counts by their row sums, we add the prior
        pseudo-counts (alpha0 or beta0) before normalising — equivalent to
        taking the mean of the posterior Dirichlet.
        """
        prev_ll  = -np.inf
        ll_curve = []

        # Dirichlet prior pseudo-counts
        prior_A  = np.full((self.N, self.N), self.alpha0)
        prior_B  = np.full((self.N, self.M), self.beta0)
        prior_pi = np.full(self.N, self.alpha0)

        for _ in range(max_iter):
            # ---- E-step ----
            A_num  = prior_A.copy()
            B_num  = prior_B.copy()
            pi_num = prior_pi.copy()
            total_ll = 0.0

            for obs in obs_list:
                obs = np.asarray(obs, dtype=int)
                gamma, xi, ll = posterior(obs, A, B, pi)
                total_ll += ll
                pi_num   += gamma[0]
                A_num    += xi.sum(axis=0)
                for m in range(self.M):
                    B_num[:, m] += gamma[obs == m].sum(axis=0)

            ll_curve.append(total_ll)

            # ---- Bayesian M-step: posterior Dirichlet means ----
            pi = pi_num / pi_num.sum()
            A  = A_num  / A_num.sum(axis=1, keepdims=True)
            B  = B_num  / B_num.sum(axis=1, keepdims=True)

            if abs(total_ll - prev_ll) < tol:
                break
            prev_ll = total_ll

        return ll_curve, A, B, pi
