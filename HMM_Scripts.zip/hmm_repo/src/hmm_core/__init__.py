"""
hmm_core — Core Hidden Markov Model algorithms.

Modules
-------
forward_backward : Forward and Backward variables (log-scaled, numerically stable)
viterbi          : Viterbi decoding (most-probable state sequence)
baum_welch       : Maximum-likelihood EM (Baum-Welch) parameter estimation
bayesian_hmm     : Bayesian-EM with Dirichlet priors on transition / initial distributions
"""

from .forward_backward import forward, backward, posterior
from .viterbi import viterbi_decode
from .baum_welch import BaumWelchHMM
from .bayesian_hmm import BayesianHMM

__all__ = [
    "forward", "backward", "posterior",
    "viterbi_decode",
    "BaumWelchHMM",
    "BayesianHMM",
]
