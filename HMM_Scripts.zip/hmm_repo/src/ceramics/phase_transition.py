"""
phase_transition.py
-------------------
Task 6 — Phase-Transition Detection in Ceramics Manufacturing.

Three-state HMM over DTA/TGA thermal analysis time series:
    State 0 : Amorphous   — low, noisy heat flow
    State 1 : Crystalline — elevated, stable heat flow
    State 2 : Molten      — sharp exothermic dip in heat flow

The hidden phase constitutes the latent state; DTA heat flow and TGA mass
loss are the observable emissions (Gaussian).

Model comparison (article Table 2):
    ML-HMM  : 87.4% accuracy, 1.2 ms inference
    B-HMM   : 90.1% accuracy, 1.4 ms inference   ← proposed
    HSMM    : 91.6% accuracy, 8.7 ms inference
    BiLSTM  : 93.2% accuracy, 24.1 ms inference

References
----------
Rajan, K. (2005). Materials informatics. Materials Today, 8(10), 38-45.
Marshall, G. et al. (2020). Machine learning in ceramics manufacturing:
    a review. J. Eur. Ceram. Soc. (illustrative citation).
"""

import numpy as np
from ..hmm_core.bayesian_hmm import BayesianHMM
from ..hmm_core.baum_welch    import BaumWelchHMM
from ..hmm_core.viterbi       import viterbi_decode

STATES     = ["Amorphous", "Crystalline", "Molten"]
N_STATES   = 3

# Gaussian emission parameters: (mean_heat_flow, std_heat_flow)
EMIT_PARAMS = {
    0: ( 0.5,  0.8),    # Amorphous
    1: ( 2.1,  0.6),    # Crystalline
    2: (-1.8,  1.2),    # Molten (exothermic)
}

# Transition matrix (article-consistent)
A_PHASE = np.array([
    [0.95, 0.04, 0.01],
    [0.02, 0.93, 0.05],
    [0.01, 0.03, 0.96],
], dtype=float)

PI_PHASE = np.array([0.70, 0.20, 0.10])


def simulate_thermal_series(n_timesteps=500, temp_range=(25, 1200), seed=42):
    """
    Simulate a DTA/TGA time series with hidden phase-transition labels.

    Parameters
    ----------
    n_timesteps : int   — number of time steps
    temp_range  : tuple — (T_start, T_end) in degrees Celsius
    seed        : int

    Returns
    -------
    time_steps    : ndarray (T,) — time indices
    temperatures  : ndarray (T,) — linearly ramped temperature [°C]
    heat_flow     : ndarray (T,) — DTA signal [mW]
    mass_loss     : ndarray (T,) — TGA signal [% mass loss]
    true_phases   : list of str  — ground-truth phase labels
    obs_discrete  : ndarray (T,) — discretised heat flow for discrete HMM
    """
    rng  = np.random.default_rng(seed)
    T    = n_timesteps
    temps = np.linspace(temp_range[0], temp_range[1], T)

    state = rng.choice(N_STATES, p=PI_PHASE)
    heat, mass, phases = [], [], []

    for t in range(T):
        mu, sigma = EMIT_PARAMS[state]
        heat.append(rng.normal(mu, sigma))
        mass.append(rng.uniform(0, 0.5) if state == 2 else rng.uniform(0, 0.1))
        phases.append(STATES[state])
        state = rng.choice(N_STATES, p=A_PHASE[state])

    heat  = np.array(heat)
    mass  = np.array(mass)
    # Discretise heat flow into 10 bins for discrete-emission HMM
    bins  = np.linspace(heat.min() - 0.1, heat.max() + 0.1, 11)
    obs_d = np.digitize(heat, bins) - 1   # 0-9

    return (np.arange(T), temps, heat, mass, phases, obs_d)


def run_phase_experiment(n_timesteps=500, alpha0=1.0, seed=42):
    """
    End-to-end phase-transition detection experiment.

    Returns
    -------
    results : dict
        Keys: ml_accuracy, b_accuracy, true_phases, ml_pred, b_pred
    """
    _, _, _, _, true_phases, obs_d = simulate_thermal_series(n_timesteps, seed=seed)
    obs_d = obs_d.tolist()

    # ML-HMM
    ml_model = BaumWelchHMM(n_states=N_STATES, n_obs=10, n_restarts=3, seed=seed)
    ml_model.fit(obs_d, max_iter=150)
    ml_pred, _ = viterbi_decode(obs_d, ml_model.A, ml_model.B, ml_model.pi)

    # B-HMM
    b_model = BayesianHMM(n_states=N_STATES, n_obs=10, alpha0=alpha0, seed=seed)
    b_model.fit(obs_d, max_iter=150)
    b_pred, _ = viterbi_decode(obs_d, b_model.A, b_model.B, b_model.pi)

    # Map integer predictions to state names (best permutation by accuracy)
    def best_mapping(pred_int, true_str):
        from itertools import permutations
        best_acc, best_map = 0.0, {0: 0, 1: 1, 2: 2}
        for perm in permutations(range(N_STATES)):
            mapping = dict(enumerate(perm))
            acc = np.mean([STATES[mapping[p]] == t
                           for p, t in zip(pred_int, true_str)])
            if acc > best_acc:
                best_acc, best_map = acc, mapping
        return best_acc, best_map

    ml_acc, ml_map = best_mapping(ml_pred, true_phases)
    b_acc,  b_map  = best_mapping(b_pred,  true_phases)

    ml_labels = [STATES[ml_map[p]] for p in ml_pred]
    b_labels  = [STATES[b_map[p]]  for p in b_pred]

    return {
        "ml_accuracy": round(ml_acc, 4),
        "b_accuracy":  round(b_acc,  4),
        "true_phases": true_phases,
        "ml_pred":     ml_labels,
        "b_pred":      b_labels,
    }
